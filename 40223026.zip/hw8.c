#include <stdio.h>
#include <stdlib.h>

struct time
{
    int min ;
    int sec ;
};

struct runner
{
    char firstName[15] ;
    char lastName[15] ;
    char ID[15] ;
    struct time *record ;
    struct time runningTime ;
};


int main()
{
    int n ;
    printf("enter number of runners:\n");
    scanf("%d",&n);

    struct runner array[n] ;

    int time[n] ;
    int record[n] ;
    
    for(int i = 0 ; i < n ; i++)
    {
        printf("for runner%d :\n", i + 1);

        printf("enter firstname:\n");
        scanf("%s",array[i].firstName);

        printf("enter lastname:\n");
        scanf("%s",array[i].lastName);

        printf("enter ID:\n");
        scanf("%s",array[i].ID);

        array[i].record = (struct time*)malloc(sizeof(struct time)) ;
        printf("enter record:\n");
        printf("minutes:\n");
        scanf("%d",&array[i].record->min);
        printf("seconds:\n");
        scanf("%d",&array[i].record->sec);
        record[i] = (array[i].record->min) * 60 + (array[i].record->sec) ;

        printf("enter runningtime:\n");
        printf("minutes:\n");
        scanf("%d",&array[i].runningTime.min);
        printf("seconds:\n");
        scanf("%d",&array[i].runningTime.sec);
        time[i] = (array[i].runningTime.min) * 60 + (array[i].runningTime.sec) ;

    }

    int min_time = time[0] ;
    int min_time_index ;

    for(int  j = 0 ; j < n ; j++)
    {
        if(time[j] < min_time)
        {
            min_time = time[j] ;
            min_time_index = j ;
        }
    }


    int min_record = record[0] ;
    int min_record_index ;

    for(int k = 0 ; k < n ; k++)
    {
        if(record[k] < min_record)
        {
            min_record = record[k] ;
            min_record_index = k ;
        }
    }

    printf("the winner is %s %s.\n" , array[min_time_index].firstName , array[min_time_index].lastName) ;

    if(time[min_time_index] < record[min_time_index])
        printf("the winner broke his record!\n") ;
    else
        printf("the winner couldn't break his record.\n") ;


    
    if(time[min_time_index] < min_record)
        printf("the winner broke the records of all runners!\n") ;
    else
        printf("the winner couldn't break the records of all runners.\n") ;


    for(int i = 0 ; i < n - 1 ; i++)
    {
        for(int j = 0 ; j < n - 1 ; j++)
        {
            if(time[j] > time[j + 1])
            {
                struct runner temp = array[j] ;
                array[j] = array [j + 1] ;
                array[j + 1] = temp ;

                int temp2 = time[j] ;
                time[j] = time [j + 1] ;
                time[j + 1] = temp2 ;

            }
        }
    }


    printf("%-15s %-15s %-15s %-15s %-15s\n", "firstname" , "lastname" , "ID" , "record" , "runningtime") ;
    printf("--------------------------------------------------------------------------\n") ;


    for(int i = 0 ; i < n ; i++)
    {
        printf("%-15s %-15s %-15s %d:%d \t\t %d:%d\n",array[i].firstName , array[i].lastName , array[i].ID 
        , array[i].record->min , array[i].record->sec 
        , array[i].runningTime.min , array[i].runningTime.sec ) ;
    }


    for(int i = 0 ; i < n ; i++)
    {
        free(array[i].record) ;
    }

    return 0 ;
}